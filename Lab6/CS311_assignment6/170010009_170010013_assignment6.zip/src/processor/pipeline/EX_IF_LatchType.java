package processor.pipeline;

public class EX_IF_LatchType {
	boolean isBranchTaken;
	int offset;
	
	public EX_IF_LatchType() {
		isBranchTaken = false;
		offset = 70000;
	}

}
