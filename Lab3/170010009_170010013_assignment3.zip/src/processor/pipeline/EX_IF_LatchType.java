package processor.pipeline;

public class EX_IF_LatchType {
	int jmpAddr;
	
	public EX_IF_LatchType() {
		jmpAddr = 70000;
	}

	public void setjmpjmpAddr(int sth) {
		this.jmpAddr = sth;
	}

	public int getjmpAddr() {
		return jmpAddr;
	}

}
